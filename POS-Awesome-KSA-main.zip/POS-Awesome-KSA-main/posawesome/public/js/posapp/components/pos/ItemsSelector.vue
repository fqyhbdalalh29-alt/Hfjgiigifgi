<template>
  <div>
    <v-card class="selection mx-auto bg-grey-lighten-5 mt-3" style="max-height: 75vh; height: 75vh">
      <v-progress-linear
        :active="loading"
        :indeterminate="loading"
        absolute
        location="top"
        color="info"
      ></v-progress-linear>

      <v-row class="items px-2 py-1">
        <v-col class="pb-0 mb-2">
          <v-text-field
            density="compact"
            clearable
            autofocus
            variant="outlined"
            color="primary"
            :label="$t('Search Items')"
            :hint="$t('Search by item code, serial number, batch no or barcode')"
            bg-color="white"
            hide-details
            v-model="debounce_search"
            @keydown.esc="esc_event"
            @keydown.enter="search_onchange"
            ref="debounce_search"
          ></v-text-field>
        </v-col>

        <v-col cols="3" class="pb-0 mb-2" v-if="pos_profile.posa_input_qty">
          <v-text-field
            density="compact"
            variant="outlined"
            color="primary"
            :label="$t('QTY')"
            bg-color="white"
            hide-details
            v-model.number="qty"
            type="number"
            @keydown.enter="enter_event"
            @keydown.esc="esc_event"
          ></v-text-field>
        </v-col>

        <v-col cols="2" class="pb-0 mb-2" v-if="pos_profile.posa_new_line">
          <v-checkbox
            v-model="new_line"
            color="accent"
            value="true"
            :label="$t('New Line')"
            density="default"
            hide-details
          ></v-checkbox>
        </v-col>

        <v-col cols="12" class="pt-0 mt-0">
          <div fluid class="items" v-if="items_view == 'card'">
            <v-row density="default" class="overflow-y-auto" style="max-height: 67vh">
              <v-col
                v-for="(item, idx) in filtered_items"
                :key="idx"
                xl="2" lg="3" md="6" sm="6" cols="6"
              >
                <v-card hover @click="add_item(item)">
                  <v-img
                    :src="item.image || '/assets/posawesome/js/posapp/components/pos/placeholder-image.png'"
                    class="text-white align-end"
                    gradient="to bottom, rgba(0,0,0,0), rgba(0,0,0,0.4)"
                    height="100px"
                  >
                    <v-card-text class="text-caption px-1 pb-0">
                      {{ item.item_name }}
                    </v-card-text>
                  </v-img>
                  <v-card-text class="text--primary pa-1">
                    <div class="text-caption text-primary">
                      {{ currencySymbol(item.currency) }} {{ formatCurrency(item.rate) }}
                    </div>
                    <div class="text-caption golden--text">
                      {{ formatFloat(item.actual_qty) }} {{ item.stock_uom }}
                    </div>
                  </v-card-text>
                </v-card>
              </v-col>
            </v-row>
          </div>

          <div fluid class="items" v-if="items_view == 'list'">
            <div class="my-0 py-0 overflow-y-auto" style="max-height: 65vh">
              <v-data-table
                :headers="getItemsHeaders()"
                :items="filtered_items"
                item-key="item_code"
                class="elevation-1"
                :items-per-page="itemsPerPage"
                hide-default-footer
                @click:row="click_item_row"
              >
                <template v-slot:item.rate="{ item }">
                  <span class="text-primary">
                    {{ currencySymbol(item.currency) }} {{ formatCurrency(item.rate) }}
                  </span>
                </template>
                <template v-slot:item.actual_qty="{ item }">
                  <span class="golden--text">
                    {{ formatFloat(item.actual_qty) }}
                  </span>
                </template>
              </v-data-table>
            </div>
          </div>
        </v-col>
      </v-row>
    </v-card>

    <v-card class="cards mb-0 mt-3 pa-2 bg-grey-lighten-5">
      <v-row no-gutters align="center" justify="center">
        <v-col cols="12">
          <v-select
            :items="items_group"
            :label="$t('items_group')"
            density="compact"
            variant="outlined"
            hide-details
            v-model="item_group"
            item-value="value"
            :item-title="(item) => item === 'ALL' ? $t('ALL') : item"
            @update:model-value="search_onchange"
          ></v-select>
        </v-col>

        <v-col cols="3" class="mt-1">
          <v-btn-toggle
            v-model="items_view"
            color="primary"
            group
            density="compact"
            rounded
          >
            <v-btn size="small" value="list">{{ $t('List') }}</v-btn>
            <v-btn size="small" value="card">{{ $t('Card') }}</v-btn>
          </v-btn-toggle>
        </v-col>

        <v-col cols="2" class="mt-2">
          <v-btn small block color="warning" text @click="show_bundles">
            {{ $t('Bundle') }}
          </v-btn>
        </v-col>

        <v-col cols="4" class="mt-2">
          <v-btn size="small" block color="primary" variant="text" @click="show_coupons">
            {{ couponsCount }} {{ $t('Coupons') }}
          </v-btn>
        </v-col>

        <v-col cols="5" class="mt-2">
          <v-btn size="small" block color="primary" variant="text" @click="show_offers">
            {{ offersCount }} {{ $t('Offers') }} : {{ appliedOffersCount }} {{ $t('Applied') }}
          </v-btn>
        </v-col>
      </v-row>
    </v-card>
  </div>
</template>

<script>
import LZString from "lz-string";
import { fr } from "vuetify/locale";
import format from "../../format";
import _ from "lodash";
export default {
  mixins: [format],
  data: () => ({
    customer_group: "",
    custom_discount_level: null,
    pos_profile: "",
    flags: {},
    items_view: "list",
    item_group: "ALL",
    loading: false,
    items_group: ["ALL"],
    items: [],
    search: "",
    first_search: "",
    itemsPerPage: 1000,
    offersCount: 0,
    appliedOffersCount: 0,
    couponsCount: 0,
    appliedCouponsCount: 0,
    customer_price_list: null,
    customer: null,
    new_line: false,
    qty: 1,
  }),

  watch: {
    customer_price_list(newVal, oldVal) {
      if (newVal !== oldVal) {
        this.get_items();
      }
    },
    custom_discount_level(newVal, oldVal) {
      if (newVal !== oldVal) {
        this.update_item_rates_by_discount_level();
      }
    },
    filtered_items(new_value, old_value) {},

    new_line() {
      this.eventBus.emit("set_new_line", this.new_line);
    },
  },

  methods: {
    update_item_rates_by_discount_level() {
      const profileType = this.pos_profile.custom_profile_type;
      const customerGroup = this.customer_group;
      this.items = this.items.map((item) => {
        let newRate = item.rate;

        newRate = item.original_rate ?? item.rate;
        return { ...item, rate: newRate };
      });

      this.eventBus.emit("set_all_items", this.items);
    },
    show_offers() {
      this.eventBus.emit("show_offers", "true");
    },
    show_coupons() {
      this.eventBus.emit("show_coupons", "true");
    },
    show_bundles() {
      this.eventBus.emit("show_bundles", "true");
    },

    get_items() {
      if (!this.pos_profile) {
        console.error("No POS Profile");
        return;
      }

      const vm = this;
      this.loading = true;

      const search = this.get_search(this.first_search);
      const gr = vm.item_group !== "ALL" ? vm.item_group.toLowerCase() : "";
      const sr = search || "";

      frappe.call({
        method: "posawesome.posawesome.api.posapp.get_items",
        args: {
          pos_profile: vm.pos_profile,
          price_list: vm.customer_price_list,
          item_group: gr,
          search_value: sr,
          customer: vm.customer,
        },
        callback: function (r) {
          console.log("Items fetched from server:", r.message);
          if (r.message) {
            vm.items = r.message.map((item) => ({
              ...item,
              rate: item.rate || 0,
              original_rate: item.rate || 0,
            }));
            console.log("Items fetched:", vm.items);

            vm.update_item_rates_by_discount_level();

            vm.loading = false;

            if (vm.pos_profile.posa_local_storage) {
              try {
                localStorage.setItem("items_storage", JSON.stringify(vm.items));
                console.log("Items saved to localStorage");
              } catch (e) {
                console.error("❌ Failed to compress/store items:", e);
              }
            }

            if (vm.pos_profile.pose_use_limit_search) {
              vm.enter_event();
            }
          } else {
            vm.loading = false;
            console.error("❌ No items returned from server.");
          }
        },
      });
    },

    get_items_groups() {
      if (!this.pos_profile) {
        return;
      }
      if (this.pos_profile.item_groups.length > 0) {
        this.pos_profile.item_groups.forEach((element) => {
          if (element.item_group !== "All Item Groups") {
            this.items_group.push(element.item_group);
          }
        });
      } else {
        const vm = this;
        frappe.call({
          method: "posawesome.posawesome.api.posapp.get_items_groups",
          args: {},
          callback: function (r) {
            if (r.message) {
              r.message.forEach((element) => {
                vm.items_group.push(element.name);
              });
            }
          },
        });
      }
    },
    getItemsHeaders() {
  const items_headers = [
    {
      title: this.$t("Name"),
      align: "start",
      sortable: true,
      key: "item_name",
    },
    {
      title: this.$t("Code"),
      align: "start",
      sortable: true,
      key: "item_code",
    },
    {
      title: this.$t("Rate"),
      key: "rate",
      align: "start"
    },
    {
      title: this.$t("Available QTY"),
      key: "actual_qty",
      align: "start"
    },
    {
      title: this.$t("Item Code"),
      key: "item_code",
      align: "start"
    }
  ];

  if (!this.pos_profile.posa_display_item_code) {
    items_headers.splice(1, 1);
  }

  return items_headers;
},

    click_item_row(event, { item }) {
      this.add_item(item);
    },
    add_item(item) {
      item = { ...item };
      if (item.has_variants) {
        this.eventBus.emit("open_variants_model", item, this.items);
      } else {
        if (!item.qty || item.qty === 1) {
          item.qty = Math.abs(this.qty);
        }
        this.eventBus.emit("add_item", item);
        this.qty = 1;
      }
    },
    enter_event() {
      let match = false;
      if (!this.filtered_items.length || !this.first_search) {
        return;
      }
      const qty = this.get_item_qty(this.first_search);
      const new_item = { ...this.filtered_items[0] };
      new_item.qty = flt(qty);
      new_item.item_barcode.forEach((element) => {
        if (this.search == element.barcode) {
          new_item.uom = element.posa_uom;
          match = true;
        }
      });
      if (
        !new_item.to_set_serial_no &&
        new_item.has_serial_no &&
        this.pos_profile.posa_search_serial_no
      ) {
        new_item.serial_no_data.forEach((element) => {
          if (this.search && element.serial_no == this.search) {
            new_item.to_set_serial_no = this.first_search;
            match = true;
          }
        });
      }
      if (this.flags.serial_no) {
        new_item.to_set_serial_no = this.flags.serial_no;
      }
      if (
        !new_item.to_set_batch_no &&
        new_item.has_batch_no &&
        this.pos_profile.posa_search_batch_no
      ) {
        new_item.batch_no_data.forEach((element) => {
          if (this.search && element.batch_no == this.search) {
            new_item.to_set_batch_no = this.first_search;
            new_item.batch_no = this.first_search;
            match = true;
          }
        });
      }
      if (this.flags.batch_no) {
        new_item.to_set_batch_no = this.flags.batch_no;
      }
      if (match) {
        this.add_item(new_item);
        this.search = null;
        this.first_search = null;
        this.debounce_search = null;
        this.flags.serial_no = null;
        this.flags.batch_no = null;
        this.qty = 1;
        this.$refs.debounce_search.focus();
      }
    },
    search_onchange() {
      const vm = this;
      if (vm.pos_profile.pose_use_limit_search) {
        vm.get_items();
      } else {
        vm.enter_event();
      }
    },
    get_item_qty(first_search) {
      let scal_qty = Math.abs(this.qty);
      if (first_search.startsWith(this.pos_profile.posa_scale_barcode_start)) {
        let pesokg1 = first_search.substr(7, 5);
        let pesokg;
        if (pesokg1.startsWith("0000")) {
          pesokg = "0.00" + pesokg1.substr(4);
        } else if (pesokg1.startsWith("000")) {
          pesokg = "0.0" + pesokg1.substr(3);
        } else if (pesokg1.startsWith("00")) {
          pesokg = "0." + pesokg1.substr(2);
        } else if (pesokg1.startsWith("0")) {
          pesokg =
            pesokg1.substr(1, 1) + "." + pesokg1.substr(2, pesokg1.length);
        } else if (!pesokg1.startsWith("0")) {
          pesokg =
            pesokg1.substr(0, 2) + "." + pesokg1.substr(2, pesokg1.length);
        }
        scal_qty = pesokg;
      }
      return scal_qty;
    },
    get_search(first_search) {
      let search_term = "";
      if (
        first_search &&
        first_search.startsWith(this.pos_profile.posa_scale_barcode_start)
      ) {
        search_term = first_search.substr(0, 7);
      } else {
        search_term = first_search;
      }
      return search_term;
    },
    esc_event() {
      this.search = null;
      this.first_search = null;
      this.qty = 1;
      this.$refs.debounce_search.focus();
    },
    update_items_details(items) {
      const vm = this;
      frappe.call({
        method: "posawesome.posawesome.api.posapp.get_items_details",
        args: {
          pos_profile: vm.pos_profile,
          items_data: items,
        },
        callback: function (r) {
          if (r.message) {
            items.forEach((item) => {
              const updated_item = r.message.find(
                (element) => element.item_code == item.item_code
              );
              item.actual_qty = updated_item.actual_qty;

              item.serial_no_data = updated_item.serial_no_data;
              item.batch_no_data = updated_item.batch_no_data;
              item.item_uoms = updated_item.item_uoms;
            });
          }
        },
      });
    },
    update_cur_items_details() {
      this.update_items_details(this.filtered_items);
    },
    scan_barcoud() {
      const vm = this;
      onScan.attachTo(document, {
        suffixKeyCodes: [],
        keyCodeMapper: function (oEvent) {
          oEvent.stopImmediatePropagation();
          return onScan.decodeKeyEvent(oEvent);
        },
        onScan: function (sCode) {
          setTimeout(() => {
            vm.trigger_onscan(sCode);
          }, 300);
        },
      });
    },
    trigger_onscan(sCode) {
      if (this.filtered_items.length == 0) {
        this.eventBus.emit("show_message", {
          text: this.$t('barcode_not_found', { code: sCode }),
          color: "error",
        });
        frappe.utils.play_sound("error");
      } else {
        this.enter_event();
        this.debounce_search = null;
        this.search = null;
      }
    },
    generateWordCombinations(inputString) {
      const words = inputString.split(" ");
      const wordCount = words.length;
      const combinations = [];

      function permute(arr, m = []) {
        if (arr.length === 0) {
          combinations.push(m.join(" "));
        } else {
          for (let i = 0; i < arr.length; i++) {
            const current = arr.slice();
            const next = current.splice(i, 1);
            permute(current.slice(), m.concat(next));
          }
        }
      }

      permute(words);

      return combinations;
    },
  },

  computed: {
    filtered_items() {
      this.search = this.get_search(this.first_search);
      if (this.pos_profile.pose_use_limit_search) {
        let filtred_list = [];
        let filtred_group_list =
          this.item_group !== "ALL"
            ? this.items.filter((item) =>
                item.item_group
                  .toLowerCase()
                  .includes(this.item_group.toLowerCase())
              )
            : this.items;
        filtred_group_list = this.items; 
        if (!this.search || this.search.length < 3) {
          return this.pos_profile.posa_show_template_items &&
            this.pos_profile.posa_hide_variants_items
            ? filtred_group_list.filter((item) => !item.variant_of).slice(0, 50)
            : filtred_group_list.slice(0, 50);
        } else {
          filtred_list = filtred_group_list.filter((item) =>
            item.item_code
              .toLowerCase()
              .replace(/\s/g, "")
              .includes(this.search.toLowerCase().replace(/\s/g, ""))
          );

          if (filtred_list.length == 0) {
            filtred_list = filtred_group_list.filter((item) => {
              if (
                item.item_code
                  .toLowerCase()
                  .split(" ")
                  .join("")
                  .includes(this.search.toLowerCase().split(" ").join(""))
              ) {
                return item;
              }
            });
          }

          let alternative_items = [];
          filtred_list.forEach((matched_item) => {
            matched_item.alternative_items?.forEach((alt) => {
              let alt_item = filtred_group_list.find(
                (item) => item.item_code === alt.alternative_item_code
              );
              if (alt_item) {
                alternative_items.push(alt_item);
              } else {
                console.log(
                  "Alternative Item Not Found:",
                  alt.alternative_item_code
                );
              }
            });
          });

          if (filtred_list.length === 0) {
            filtred_list = filtred_group_list.filter((item) =>
              item.item_manufacturer_part_no
                ?.toLowerCase()
                .includes(this.search.toLowerCase())
            );
          }

          if (filtred_list.length === 0) {
            filtred_list = filtred_group_list.filter((item) =>
              item.item_name
                .toLowerCase()
                .replace(/\s/g, "")
                .includes(this.search.toLowerCase().replace(/\s/g, ""))
            );
          }

          if (filtred_list.length === 0) {
            filtred_list = filtred_group_list.filter((item) =>
              item.item_barcode.some(
                (barcodeData) => barcodeData.barcode === this.search
              )
            );
          }

          if (
            filtred_list.length === 0 &&
            this.pos_profile.posa_search_serial_no
          ) {
            filtred_list = filtred_group_list.filter((item) =>
              item.serial_no_data.some(
                (serial) => serial.serial_no === this.search
              )
            );
          }

          let final_list = [
            ...new Set([...filtred_list, ...alternative_items]),
          ];

          return this.pos_profile.posa_show_template_items &&
            this.pos_profile.posa_hide_variants_items
            ? final_list.filter((item) => !item.variant_of).slice(0, 50)
            : final_list.slice(0, 50);
        }
      } else {
        return this.items.slice(0, 50);
      }
    },
    debounce_search: {
      get() {
        return this.first_search;
      },
      set: _.debounce(function (newValue) {
        this.first_search = newValue;
      }, 200),
    },
  },

  created: function () {
    this.eventBus.on("update_profile_type", (type) => {
      if (this.pos_profile) {
        this.pos_profile.custom_profile_type = type;
      }
    });

    this.eventBus.on("update_customer_group", (group) => {
      this.customer_group = group;
    });
    this.eventBus.on("update_customer_discount_level", (level) => {
      if (this.custom_discount_level !== level) {
        this.custom_discount_level = level;
      }
    });

    this.$nextTick(function () {});
    this.eventBus.on("register_pos_profile", (data) => {
      this.pos_profile = data.pos_profile;
      this.get_items();
      this.get_items_groups();
      this.items_view = this.pos_profile.posa_default_card_view
        ? "card"
        : "list";
    });
    this.eventBus.on("update_cur_items_details", () => {
      this.update_cur_items_details();
    });

    this.eventBus.on("update_offers_counters", (data) => {
      this.offersCount = data.offersCount;
      this.appliedOffersCount = data.appliedOffersCount;
    });
    this.eventBus.on("update_coupons_counters", (data) => {
      this.couponsCount = data.couponsCount;
      this.appliedCouponsCount = data.appliedCouponsCount;
    });
    this.eventBus.on("update_customer_price_list", (data) => {
      this.customer_price_list = data;
    });
    this.eventBus.on("update_customer", (data) => {
      this.customer = data;
    });
  },

  mounted() {
    this.scan_barcoud();
  },
};
</script>

<style scoped></style>
